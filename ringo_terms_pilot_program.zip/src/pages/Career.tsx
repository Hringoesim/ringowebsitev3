import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Users, Globe, Zap } from "lucide-react";
import { Link } from "react-router-dom";

const Career = () => {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Fixed Navigation */}
      <header className="border-b bg-white/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <span className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
                Ringo
              </span>
            </Link>
            
            <div className="hidden md:flex md:items-center md:space-x-8">
              <Link to="/" className="text-sm font-medium transition-colors hover:text-orange-500 text-gray-600">
                Home
              </Link>
              <Link to="/#pricing" className="text-sm font-medium transition-colors hover:text-orange-500 text-gray-600">
                Plans
              </Link>
              <Link to="/use-cases" className="text-sm font-medium transition-colors hover:text-orange-500 text-gray-600">
                Use Cases
              </Link>
              <Link to="/how-it-works" className="text-sm font-medium transition-colors hover:text-orange-500 text-gray-600">
                About
              </Link>
              <Link to="/contact" className="text-sm font-medium transition-colors hover:text-orange-500 text-gray-600">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-orange-500 to-pink-500 text-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center">
              <h1 className="text-4xl sm:text-5xl font-bold mb-6">Join Our Mission</h1>
              <p className="text-xl text-orange-100 max-w-3xl mx-auto">
                Help us revolutionize global connectivity and build the future of travel communication
              </p>
            </div>
          </div>
        </section>

        {/* Career Opportunity */}
        <section className="py-20 bg-white">
          <div className="max-w-4xl mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Want to Join Our Mission?</h2>
              <p className="text-xl text-gray-600 mb-8">
                We're building something revolutionary in the global connectivity space. 
                If you're passionate about technology, travel, and making a real impact, we'd love to hear from you.
              </p>
              
              <Card className="max-w-2xl mx-auto">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Mail className="h-8 w-8 text-orange-600" />
                  </div>
                  <CardTitle className="text-2xl">Send Us Your CV</CardTitle>
                </CardHeader>
                <CardContent className="text-center space-y-6">
                  <p className="text-gray-600 text-lg">
                    Please send over your CV at <strong>info@ringoesim.com</strong>
                  </p>
                  
                  <Button 
                    className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white px-8 py-6 text-lg"
                    onClick={() => window.location.href = 'mailto:info@ringoesim.com?subject=Career Opportunity - CV Submission&body=Hi Ringo team,%0D%0A%0D%0AI am interested in joining your mission and would like to submit my CV for consideration.%0D%0A%0D%0APlease find my CV attached.%0D%0A%0D%0ABest regards'}
                  >
                    Send Your CV
                  </Button>
                  
                  <p className="text-sm text-gray-500">
                    Include your CV as an attachment and tell us why you want to join Ringo
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Why Join Ringo */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Join Ringo?</h2>
              <p className="text-xl text-gray-600">Be part of the team that's changing how the world stays connected</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Card className="text-center">
                <CardHeader>
                  <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Globe className="h-8 w-8 text-orange-600" />
                  </div>
                  <CardTitle className="text-lg">Global Impact</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">Work on technology that connects people across 180+ countries worldwide.</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardHeader>
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Zap className="h-8 w-8 text-green-600" />
                  </div>
                  <CardTitle className="text-lg">Innovation</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">Push the boundaries of what's possible in global connectivity and eSIM technology.</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardHeader>
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="h-8 w-8 text-blue-600" />
                  </div>
                  <CardTitle className="text-lg">Small Team</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">Make a real difference in a growing startup where every contribution matters.</p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardHeader>
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Globe className="h-8 w-8 text-purple-600" />
                  </div>
                  <CardTitle className="text-lg">Global Offices</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">Possible office locations in London, San Francisco, and other locations TBA.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-orange-500 to-pink-500 text-white">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Make an Impact?</h2>
            <p className="text-xl text-orange-100 mb-8 max-w-2xl mx-auto">
              Join us in building the future of global connectivity. Send us your CV today.
            </p>
            <Button 
              size="lg" 
              className="bg-white text-orange-600 hover:bg-orange-50 font-semibold px-8 py-6 text-lg"
              onClick={() => window.location.href = 'mailto:info@ringoesim.com?subject=Career Opportunity - CV Submission&body=Hi Ringo team,%0D%0A%0D%0AI am interested in joining your mission and would like to submit my CV for consideration.%0D%0A%0D%0APlease find my CV attached.%0D%0A%0D%0ABest regards'}
            >
              Send Your CV Now
            </Button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Ringo</h3>
              <p className="text-sm font-medium text-gray-300">One Number. One Plan. Everywhere.</p>
              <p className="text-gray-400 text-sm">
                Stay connected globally using your existing phone number.
              </p>
              <div className="flex items-center space-x-2 pt-4">
                <a 
                  href="https://www.linkedin.com/company/ringoesim/?viewAsMember=true" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center w-10 h-10 bg-blue-600 hover:bg-blue-700 rounded-lg transition-all duration-200 hover:scale-105"
                  aria-label="Visit RingoESIM on LinkedIn"
                >
                  <svg className="h-5 w-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                  </svg>
                </a>
                <span className="text-sm text-gray-400">Follow us on LinkedIn</span>
              </div>
            </div>
            
            {/* Company Section */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-white">Company</h4>
              <div className="space-y-2">
                <Link to="/how-it-works" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  How It Works
                </Link>
                <Link to="/#pricing" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Pricing
                </Link>
                <Link to="/device-compatibility" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Device Compatibility
                </Link>
                <Link to="/contact" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Contact
                </Link>
                <Link to="/career" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Careers
                </Link>
              </div>
            </div>
            
            {/* Support Section */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-white">Support</h4>
              <div className="space-y-2">
                <Link to="/faq" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  FAQ
                </Link>
                <a href="mailto:info@ringoesim.com" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Email Support
                </a>
                <Link to="/device-compatibility" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Check Compatibility
                </Link>
              </div>
            </div>
            
            {/* Legal Section */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-white">Legal</h4>
              <div className="space-y-2">
                <Link to="/privacy" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Privacy Policy
                </Link>
                <Link to="/terms" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Terms of Service
                </Link>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8">
            <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
              <p className="text-xs text-gray-500">© 2025 Ringo. All rights reserved.</p>
              <div className="flex items-center space-x-4">
                <a href="mailto:info@ringoesim.com" className="text-xs text-gray-500 hover:text-orange-500 transition-colors">
                  info@ringoesim.com
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Career;