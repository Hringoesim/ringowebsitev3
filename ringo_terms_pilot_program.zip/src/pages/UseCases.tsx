import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X, Phone, Globe, Zap, AlertTriangle, Clock } from "lucide-react";
import SavingsCalculator from "@/components/SavingsCalculator";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

const UseCases = () => {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navigation currentPage="use-cases" />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-to-br from-orange-500 to-pink-500 text-white">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">
              Stop Paying Roaming Robbery
            </h1>
            <p className="text-xl text-orange-100 mb-8">
              Traditional carriers charge <strong>€5-€25 per day</strong> for roaming passes, 
              plus expensive overage fees. That's <strong>€150-€750 per month</strong> just for travel connectivity.
            </p>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 max-w-2xl mx-auto">
              <p className="text-lg">
                <strong>Ringo:</strong> One global plan. No daily fees. No overage charges.
              </p>
            </div>
          </div>
        </section>

        {/* Interactive Calculator Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4">
            <SavingsCalculator />
          </div>
        </section>

        {/* The Problem Section */}
        <section className="py-20 bg-white">
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                The Current "Solutions" Are Expensive
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Every current option costs you extra money and creates complications.
              </p>
            </div>
            
            <div className="grid lg:grid-cols-3 gap-8">
              <Card className="border-red-200">
                <CardHeader>
                  <CardTitle className="flex items-center text-red-800">
                    <X className="h-6 w-6 mr-3" />
                    Roaming Passes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-2xl font-bold text-red-600">€5-€25/day</div>
                    <div className="text-sm text-gray-600">Plus overage fees</div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start">
                        <X className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>€150-€750 per month for frequent travelers</span>
                      </li>
                      <li className="flex items-start">
                        <X className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Limited data allowances</span>
                      </li>
                      <li className="flex items-start">
                        <X className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Expensive overage charges</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-red-200">
                <CardHeader>
                  <CardTitle className="flex items-center text-red-800">
                    <X className="h-6 w-6 mr-3" />
                    Local SIM Cards
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-2xl font-bold text-red-600">€10-€50/month</div>
                    <div className="text-sm text-gray-600">On top of home plan</div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start">
                        <X className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Different number - people can't reach you</span>
                      </li>
                      <li className="flex items-start">
                        <X className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Setup hassle in every country</span>
                      </li>
                      <li className="flex items-start">
                        <X className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Managing multiple SIMs</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-red-200">
                <CardHeader>
                  <CardTitle className="flex items-center text-red-800">
                    <X className="h-6 w-6 mr-3" />
                    Travel eSIMs
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-2xl font-bold text-red-600">€5-€30/trip</div>
                    <div className="text-sm text-gray-600">Data only, no calls</div>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start">
                        <X className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Data only - no calls to your number</span>
                      </li>
                      <li className="flex items-start">
                        <X className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>People calling you get voicemail</span>
                      </li>
                      <li className="flex items-start">
                        <X className="h-4 w-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Limited country coverage</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Ringo Solution */}
        <section className="py-20 bg-gradient-to-br from-green-500 to-emerald-500 text-white">
          <div className="max-w-6xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-6">
                The Ringo Solution
              </h2>
              <p className="text-xl text-green-100 max-w-3xl mx-auto">
                One Number. One Plan. Everywhere.
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Check className="h-6 w-6 text-green-400 mr-3" />
                    Monthly Plan
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-white">
                  <div className="space-y-4">
                    <div className="text-3xl font-bold">€39.90/month*</div>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Unlimited global data</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Keep your existing number</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                        <span>180+ countries included</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                        <span>No daily fees, no overage charges</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Zap className="h-6 w-6 text-yellow-400 mr-3" />
                    Day Pass Option
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-white">
                  <div className="space-y-4">
                    <div className="text-3xl font-bold">€4.90/day*</div>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Perfect for short trips</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Same unlimited data</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                        <span>No commitment required</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-4 w-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                        <span>Activate only when traveling</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-12">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 max-w-4xl mx-auto">
                <h3 className="text-2xl font-bold mb-4">Compare the Savings</h3>
                <div className="grid md:grid-cols-3 gap-6 text-center">
                  <div>
                    <div className="text-3xl font-bold text-red-300 mb-2">€25/day</div>
                    <div className="text-sm">Traditional roaming pass</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-yellow-300 mb-2">€4.90/day</div>
                    <div className="text-sm">Ringo day pass</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-green-300 mb-2">€20.10</div>
                    <div className="text-sm">Saved per day</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Simple Examples */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Real Examples
              </h2>
              <p className="text-xl text-gray-600">
                See how much you save in common travel scenarios
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>🏖️ 1-Week Vacation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Traditional roaming (7 days × €15/day):</span>
                      <span className="font-bold text-red-600">€105</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Ringo day pass (7 days × €4.90/day):</span>
                      <span className="font-bold text-green-600">€34.30</span>
                    </div>
                    <div className="border-t pt-2">
                      <div className="flex justify-between items-center text-lg font-bold">
                        <span>You save:</span>
                        <span className="text-blue-600">€70.70</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>✈️ Business Travel (Monthly)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Traditional roaming (15 days × €20/day):</span>
                      <span className="font-bold text-red-600">€300</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Ringo monthly plan:</span>
                      <span className="font-bold text-green-600">€39.90</span>
                    </div>
                    <div className="border-t pt-2">
                      <div className="flex justify-between items-center text-lg font-bold">
                        <span>You save:</span>
                        <span className="text-blue-600">€260.10</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Disclaimer Section */}
        <section className="py-12 bg-gray-100">
          <div className="max-w-4xl mx-auto px-4">
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="p-6">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="h-6 w-6 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-amber-900 mb-2">Upcoming Product</h3>
                    <p className="text-amber-800 text-sm leading-relaxed">
                      <strong>Ringo is launching soon.</strong> Pricing shown (€39.90/month, €4.90/day) is projected for the upcoming product. 
                      Actual plans may vary. Traditional carrier costs are examples based on typical roaming rates.
                    </p>
                    <div className="flex items-center mt-3 text-xs text-amber-700">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Last updated: November 25, 2025</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default UseCases;