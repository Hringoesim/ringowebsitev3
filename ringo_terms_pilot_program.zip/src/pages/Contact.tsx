import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Mail, MessageSquare, Clock, Linkedin, Menu } from "lucide-react";
import { Link } from "react-router-dom";
import EnhancedContactForm from "@/components/EnhancedContactForm";

const Contact = () => {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Fixed Navigation */}
      <header className="border-b bg-white/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <span className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
                Ringo
              </span>
            </Link>
            
            <div className="hidden md:flex md:items-center md:space-x-8">
              <Link to="/" className="text-sm font-medium transition-colors hover:text-orange-500 text-gray-600">
                Home
              </Link>
              <Link to="/#pricing" className="text-sm font-medium transition-colors hover:text-orange-500 text-gray-600">
                Plans
              </Link>
              <Link to="/use-cases" className="text-sm font-medium transition-colors hover:text-orange-500 text-gray-600">
                Use Cases
              </Link>
              <Link to="/how-it-works" className="text-sm font-medium transition-colors hover:text-orange-500 text-gray-600">
                About
              </Link>
              <Link to="/contact" className="text-sm font-medium transition-colors hover:text-orange-500 text-orange-500">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-orange-500 to-pink-500 text-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center">
              <Link 
                to="/" 
                className="inline-flex items-center gap-2 text-orange-100 hover:text-white transition-colors mb-6"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Link>
              <h1 className="text-4xl sm:text-5xl font-bold mb-6">Get in Touch</h1>
              <p className="text-xl text-orange-100 max-w-3xl mx-auto">
                Have questions about Ringo? We're here to help you stay connected globally.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <div>
                <EnhancedContactForm />
              </div>

              {/* Contact Information */}
              <div className="space-y-8">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Mail className="h-5 w-5 text-orange-500" />
                      Email Us
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      For general inquiries, support, or partnership opportunities:
                    </p>
                    <a 
                      href="mailto:info@ringoesim.com" 
                      className="text-orange-600 hover:text-orange-700 font-medium text-lg"
                    >
                      info@ringoesim.com
                    </a>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageSquare className="h-5 w-5 text-blue-500" />
                      Quick Questions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <h4 className="font-medium text-gray-900">Pricing & Plans</h4>
                        <p className="text-sm text-gray-600">Questions about our €39.90/month global plan</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Technical Support</h4>
                        <p className="text-sm text-gray-600">Help with setup, compatibility, or connectivity</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Business Partnerships</h4>
                        <p className="text-sm text-gray-600">Interested in working together?</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-green-500" />
                      Response Time
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          Fast Response
                        </Badge>
                        <span className="text-sm text-gray-600">Usually within 24 hours</span>
                      </div>
                      <p className="text-sm text-gray-600">
                        We're committed to helping you get connected quickly and efficiently.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Linkedin className="h-5 w-5 text-blue-600" />
                      Connect With Us
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">
                      Follow our journey and stay updated with the latest news:
                    </p>
                    <a 
                      href="https://www.linkedin.com/company/ringoesim/?viewAsMember=true" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium"
                    >
                      <Linkedin className="h-4 w-4" />
                      Follow us on LinkedIn
                    </a>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Ringo</h3>
              <p className="text-sm text-gray-400">One Number. One Plan. Everywhere.</p>
              <p className="text-sm text-gray-400">
                Stay connected globally using your existing phone number.
              </p>
            </div>
            
            {/* Company Section */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-white">Company</h4>
              <div className="space-y-2">
                <Link to="/how-it-works" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  How It Works
                </Link>
                <Link to="/#pricing" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Pricing
                </Link>
                <Link to="/device-compatibility" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Device Compatibility
                </Link>
                <Link to="/contact" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Contact
                </Link>
                <Link to="/careers" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Careers
                </Link>
              </div>
            </div>
            
            {/* Support Section */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-white">Support</h4>
              <div className="space-y-2">
                <Link to="/faq" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  FAQ
                </Link>
                <a href="mailto:info@ringoesim.com" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Email Support
                </a>
                <Link to="/device-compatibility" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Check Compatibility
                </Link>
              </div>
            </div>
            
            {/* Legal Section */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-white">Legal</h4>
              <div className="space-y-2">
                <Link to="/privacy" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Privacy Policy
                </Link>
                <Link to="/terms" className="block text-sm text-gray-400 hover:text-white transition-colors">
                  Terms of Service
                </Link>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8">
            <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
              <p className="text-xs text-gray-500">© 2025 Ringo. All rights reserved.</p>
              <div className="flex items-center space-x-4">
                <a href="mailto:info@ringoesim.com" className="text-xs text-gray-500 hover:text-orange-500 transition-colors">
                  info@ringoesim.com
                </a>
                <a 
                  href="https://www.linkedin.com/company/ringoesim/?viewAsMember=true" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-gray-500 hover:text-orange-500 transition-colors"
                >
                  <Linkedin className="h-4 w-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Contact;